function saluer() {
  const message = document.getElementById("message");
  message.textContent = "Bonjour 👋 Je suis ETERNEL, votre assistant personnel.";
}

function parler() {
  const message = document.getElementById("message");
  const texte = "Bonjour, je suis ETERNEL, votre assistant personnel.";
  message.textContent = "🔊 ETERNEL parle...";

  if (window.AndroidTTS && typeof window.AndroidTTS.speak === "function") {
    window.AndroidTTS.speak(texte);
    setTimeout(() => {
      message.textContent = "✅ ETERNEL a terminé de parler.";
    }, 2500);
    return;
  }

  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
    const voix = new SpeechSynthesisUtterance(texte);
    voix.lang = "fr-FR";
    voix.rate = 1;
    voix.pitch = 1;
    voix.volume = 1;
    voix.onend = () => message.textContent = "✅ ETERNEL a terminé de parler.";
    voix.onerror = () => message.textContent = "⚠️ Un problème est survenu avec la voix.";
    window.speechSynthesis.speak(voix);
  } else {
    message.textContent = "⚠️ La fonction vocale n'est pas disponible.";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("startButton").addEventListener("click", saluer);
  document.getElementById("talkButton").addEventListener("click", parler);
});
