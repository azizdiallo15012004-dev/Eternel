package com.eternel.assistant;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class MainActivity extends Activity {
 private TextToSpeech tts;
 @Override public void onCreate(Bundle b){
  super.onCreate(b);
  tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS)tts.setLanguage(Locale.FRENCH);});
  WebView w=new WebView(this);
  w.getSettings().setJavaScriptEnabled(true);
  w.addJavascriptInterface(new VoiceBridge(),"AndroidTTS");
  w.loadUrl("file:///android_asset/index.html");
  setContentView(w);
 }
 public class VoiceBridge {
  @JavascriptInterface public void speak(String text){if(tts!=null)tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"ETERNEL");}
 }
 @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
