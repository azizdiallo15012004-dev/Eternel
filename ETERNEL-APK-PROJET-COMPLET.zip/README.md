# ETERNEL
Projet Android de l'assistant personnel ETERNEL.
